import torch
import numpy as np
from PIL import Image
from transformers import SamModel, SamProcessor
from diffusers import AutoPipelineForInpainting
import os

# Reduce fragmentation to help with memory
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "max_split_size_mb:32"

def get_processed_inputs(model, processor, device, image, input_points):
    inputs = processor(images=image, input_points=input_points, return_tensors="pt")
    inputs = {k: v.to(device) for k, v in inputs.items()}
    with torch.no_grad():
        outputs = model(**inputs)
    masks = processor.post_process_masks(
        outputs.pred_masks.cpu(),
        inputs["original_sizes"].cpu(),
        inputs["reshaped_input_sizes"].cpu()
    )
    mask = masks[0].cpu().numpy()
    # Squeeze to get (channels, H, W) or (H, W)
    while len(mask.shape) > 2:
        mask = np.squeeze(mask, axis=0)
    return mask

def mask_to_rgb(mask):
    # mask shape: (H, W) with bool or float mask values [0,1]
    return np.stack([mask * 255]*3, axis=-1).astype(np.uint8)

def inpaint(pipe, raw_image, input_mask, prompt, negative_prompt=None, seed=74294536, cfgs=7):
    mask_2d = input_mask
    if mask_2d.ndim != 2:
        raise ValueError(f"Expected 2D mask, got shape {mask_2d.shape}")

    mask_image = Image.fromarray((mask_2d * 255).astype(np.uint8))
    generator = torch.manual_seed(seed)

    torch.cuda.empty_cache()

    with torch.autocast("cuda") if torch.cuda.is_available() else torch.cpu.amp.autocast():
        result = pipe(
            prompt=prompt,
            negative_prompt=negative_prompt,
            image=raw_image,
            mask_image=mask_image,
            generator=generator,
            guidance_scale=cfgs,
        ).images[0]

    return result

def main():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Using device: {device}")

    print("Loading SAM model and processor...")
    model = SamModel.from_pretrained("facebook/sam-vit-base", torch_dtype=torch.float32).to(device)
    processor = SamProcessor.from_pretrained("facebook/sam-vit-base")

    print("Loading inpainting pipeline...")
    pipe = AutoPipelineForInpainting.from_pretrained(
        "runwayml/stable-diffusion-inpainting",
        torch_dtype=torch.float16 if device == "cuda" else torch.float32
    )
    pipe.to(device)

    pipe.enable_attention_slicing()
    pipe.enable_model_cpu_offload()

    # Load and resize image
    image_path = "car.png"  # Replace with your input image path
    raw_image = Image.open(image_path).convert("RGB").resize((256, 256))

    # Example input points (adjust these accordingly)
    input_points = [[[150, 170], [200, 210]]]

    print("Generating mask...")
    mask = get_processed_inputs(model, processor, device, raw_image, input_points)
    print(f"Mask shape: {mask.shape}")

    # Choose first mask if multiple channels
    if mask.ndim == 3:
        single_mask = mask[0]
    else:
        single_mask = mask

    rgb_mask = mask_to_rgb(single_mask)

    # Save mask visualization
    Image.fromarray(rgb_mask).save("mask_visualization.png")
    print("Mask visualization saved as 'mask_visualization.png'")

    # Inpainting prompt
    prompt = "A futuristic car driving on Mars, highly detailed, studio lighting"
    negative_prompt = "blurry, artifacts, low quality"

    print("Running inpainting...")
    result = inpaint(pipe, raw_image, single_mask, prompt, negative_prompt)
    result.save("inpainting_result.png")
    print("Inpainting result saved as 'inpainting_result.png'")

if __name__ == "__main__":
    main()
